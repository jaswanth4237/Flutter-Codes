package com.example.smart_agri_connect

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
